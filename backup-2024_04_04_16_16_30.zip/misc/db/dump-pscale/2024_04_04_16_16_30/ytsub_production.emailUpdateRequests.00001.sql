INSERT INTO `emailUpdateRequests`(`id`,`userId`,`email`,`code`,`createdAt`,`updatedAt`,`verifiedAt`) VALUES
(1,1,"hi.ogawa.zz@gmail.com","849af90d3501613041093feffabd2d6eb9b38d2bfa1c263fecb71a001efa17c6","2023-05-27 15:22:53.892","2023-05-27 15:23:10.513","2023-05-27 15:23:10.499");
