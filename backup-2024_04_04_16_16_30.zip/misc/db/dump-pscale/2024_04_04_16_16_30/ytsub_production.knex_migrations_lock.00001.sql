INSERT INTO `knex_migrations_lock`(`index`,`is_locked`) VALUES
(1,0);
