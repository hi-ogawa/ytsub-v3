INSERT INTO `users`(`id`,`username`,`passwordHash`,`email`,`createdAt`,`updatedAt`,`language1`,`language2`,`timezone`) VALUES
(1,"hiroshi","$argon2id$v=19$m=19456,t=2,p=1$Y21nhL9vNLO3tsGPC9SVfg$5RvyiyLfb4R9VPN4UimZSIFMjjM5p1xvsNNfcPPVZMw","hi.ogawa.zz@gmail.com","2022-04-02 09:14:47","2023-09-23 09:42:45","ko","en","+09:00"),
(2,"vue","$2a$10$7TaKWTIEE4jPOE6TfrIwvO29uy/zPntxRYU7z7IbDV16Uw/C1OUeK",NULL,"2022-04-23 18:20:39","2022-04-23 18:26:40","de","en","+00:00"),
(3,"hiroshi-recaptcha","$2a$10$NRfH7E28OpwGywjC9Yu/1etvDBGBY221d5Ogvt.ey5oqCJdpfdzFS",NULL,"2022-05-22 02:20:28","2022-05-22 02:20:28",NULL,NULL,"+00:00"),
(4,"hiroshi.recaptcha.mobile","$2a$10$Ed5GJBpY7845ToUsmmZEEuAYH8ZSG.c/xg54FT4AHmReqb1lS0uPC",NULL,"2022-05-22 22:25:44","2022-05-22 22:25:44",NULL,NULL,"+00:00"),
(5,"testo","$2a$10$pJbuXKBE/21GvMUMEi0ZxuUOW06gQqxxwYSMLPvztNzm7zsCdQjTq",NULL,"2023-03-12 14:47:01","2023-03-12 14:47:01",NULL,NULL,"+01:00"),
(6,"turnstile-test","$2a$10$inXaAVgpidKnXfd5aBD6A.W47G/lVP26xHacDP2PrplrDT4nbnEDu",NULL,"2023-05-26 04:30:43","2023-05-26 04:30:43",NULL,NULL,"+09:00"),
(7,"dev-argon","$argon2id$v=19$m=65536,t=3,p=4$EZfbQ3CU1P+sUeZXWlw6QQ$xmRaKU/oopPh72CsM/Uw+ZKdjvlanagc/bsl50GQhok",NULL,"2023-06-10 08:39:15","2023-06-10 08:39:15",NULL,NULL,"+09:00"),
(8,"tmuco","$argon2id$v=19$m=19456,t=2,p=1$O8Ec5CuP5rJo8wk/PYtT4A$wpmXy7qZOvFJuZCYZSBL3CR5cEyDsTmbbVvZjf7XClU",NULL,"2023-11-24 08:39:56","2023-11-24 08:39:56",NULL,NULL,"+02:00");
